//
//  RxEducationProvider.swift
//  RxSwiftEducation
//
//  Created by Nikolay Churyanin on 07/04/2019.
//  Copyright © 2019 Nikolay Churyanin. All rights reserved.
//

import RxSwift
import RxCocoa

/**
 Протокол содетжит методы, которые необходимо реализовать в соответствии с описанием.
 Изучение операторов RxSwift.
*/
protocol RxEducationProvider {
    
    /**
     Переключает so на другую последовательность, как только она начинает эмитить значения.
     
     - Parameters:
        - source: Исходная последовательность.
        - another: Другая последовательность.

     - Returns: Результирующая последовательность.
     */
    func switchWhenNeeded<E>(source: Observable<E>, another: Observable<E>) -> Observable<E>
    
    
    /**
     Инвертирует значение `enabled` в [EducationEntity] по id.
     
     - Parameters:
        - source: Исходная последовательность.
        - signal: Последовательность с id для инвертации.
     
     - Returns: Результирующая последовательность.
     */
    func update<E: EducationEntity>(source: Observable<[E]>, by signal: Observable<String>) -> Observable<[E]>
    
    /**
     SO испускает элементы, случаеные целые числа. По сигналу 'signal',
     берется последнее значение из SO (один эмит бертся один раз).
     Таких эмитов берется всего 5. На выходе все 5
     значений суммируются. Ошибки заменяются на число 13.
     
     - Parameters:
        - source: Исходная последовательность.
        - signal: Последовательность для фильтрации исходной последовательности.
     
     - Returns: Результирующая последовательность.
     */
    func filter(source: Observable<Int>, by signal: Observable<Void>) -> Observable<Int>
    
    /**
     SO испускает беспорядочно элементы. Первое значение берется, далее пропускаются все значения,
     сгенерированные за период 3 и так далее. Необходимо предусмотреть фильтрацию оинаковых подряд
     значений, в RO идет результат сравнения последних 2-х значений.
     
     - Parameter source: Исходная последовательность.
     
     - Returns: Результирующая последовательность.
     */
    func compareLastElements<E: Equatable>(source: Observable<E>) -> Observable<Bool>
    
    /**
     SO испускает беспорядочно элементы. Берется одно последнее значение сгенерированное за период 0.7.
     Необходимо предусмотреть попадания в RO только уникальных значений.
     В RO идет индекс максимального значения в последовательности, если значения не будет,
     последовательность просто завершается.
     
     - Parameter source: Исходная последовательность.
     
     - Returns: Результирующая последовательность.
     */
    func maxIndex<E: Comparable>(source: Observable<E>) -> Observable<Int>
    
    /**.
     По сигналу source - выполняется последовательность request, где request - запрос,
     причем source может быть несколько эмитов, необходимо чтобы доработали все request.
     В случае ошибки в request необходимо завершать последовательность. Если кол-во эмитов больше 1,
     необходимо все эмиты собрать в один, трансформировать в Void и вернуть, в противном случае
     завершить последовательность.
     
     - Parameters:
        - source: Стартовый сигнал.
        - request: Запрос, осуществляемый по сигналу source.
     
     - Returns: Результирующая последовательность.
     */
    func ifNotEmptyReduceToVoid<E1, E2>(source: Observable<E1>, request: Observable<E2>) -> Observable<Void>
}

/**
 Протокол содетжит методы, которые необходимо реализовать в соответствии с описанием.
 Изучение операторов RxSwift.
 */
protocol RxRetryAlertProvider: class {
    
    ///Результат показа алерта.
    associatedtype Result
    
    /**
     Показывает алерт, возвращает последовательность с результатом.
     
     - Parameters:
     - title: заголовок алерта.
     - message: описание ошибки.
     
     - Returns: Результирующая последовательность.
     */
    func showAlert(title: String, message: String) -> Observable<Result>
}

/**
 Протокол содетжит методы, которые необходимо реализовать в соответствии с описанием.
 Изучение операторов RxSwift.
 */
protocol RxEducationUIProvider {
    
    /// Контроллер с которого можно показать алерт.
    associatedtype RetryAlertOwner = (UIViewController & RxRetryAlertProvider)
    
    /**
     SO - результат запроса, который может вернуть как данные, так и ошибку.
     В случае ошибки открывается алерт с описанием ошибки и 2-мя кнопками: [Повторить], [Ок].
     По нажатию [Повторить] - запрос повторяется, по нажатию [Oк] - ошибка летит дальше по цепочке.
     
     - Parameters:
        - source: Исходная последовательность.
        - owner: контроллер, с которого отображается алерт.
     
     - Returns: Результирующая последовательность.
     */
    func showRetryAlert<E>(source: Observable<E>, _ owner: RetryAlertOwner) -> Observable<E>
}

/// Вспомогательный протокол.
protocol EducationEntity {
    var id: String { get }
    var enabled: Bool { get set }
}
