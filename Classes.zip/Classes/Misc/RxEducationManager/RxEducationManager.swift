//
//  RxEducationManager.swift
//  RxSwiftEducation
//
//  Created by Nikolay Churyanin on 08/04/2019.
//  Copyright © 2019 Nikolay Churyanin. All rights reserved.
//

import RxSwift

final class RxEducationManager {}

extension RxEducationManager {
    
    struct Input<R: RxEducationUIProvider> {
        
        let provider: RxEducationProvider
        let uiProvider: R
        let retryAlertOwner: R.RetryAlertOwner
    }
    
    struct Output {
        
        let switchedSequence: Observable<Int>
        let filteredBySignal: Observable<Int>
        let comparedValuesInSequence: Observable<Bool>
        let maxIndex: Observable<Int>
        let reducedSequence: Observable<Void>
        let updatedSequence: Observable<[EducationEntity]>
        let showRetryAlert: Observable<String>
    }
    
    func configure<R: RxEducationUIProvider>(input: Input<R>) -> Output {
        
        let firstSequence = Observable<Int>.interval(2, scheduler: MainScheduler.instance)
        let secondSequence = Observable<Int>.interval(6, scheduler: MainScheduler.instance).take(4)
        
        let switchedSequence = input.provider.switchWhenNeeded(
            source: firstSequence.debug("[:switchedSequence.source]"),
            another: secondSequence.debug("[:switchedSequence.another]")
        ).debug("[:switchedSequence.Result]")
        
        let filteredSequence = Observable<Int>.merge(
            Observable<Int>.of(1, 1, 1, 1, 1, 1).delay(4, scheduler: MainScheduler.instance),
            Observable<Int>.just(1).delay(3, scheduler: MainScheduler.instance),
            Observable<Int>.just(1).delay(9, scheduler: MainScheduler.instance),
            Observable<Int>.generate(
                initialState: 0,
                condition: { $0 < 66 },
                iterate: { $0 * 2 + 3 }
            ).flatMap {
                Observable<Int>.just($0).delay(RxTimeInterval($0 / 10), scheduler: MainScheduler.instance)
            }
        )
        
        let filteredBySignal = input.provider.filter(
            source: filteredSequence.debug("[:filter.source]"),
            by: firstSequence.map { _ in () }.debug("[:filter.by]")
        ).debug("[:filter.Result]")
        
        let timer = Observable.zip(
            Observable<Int>.of(1, 1, 1, 1, 1, 6, 7, 2, 9, 1, 13, 4, 4, 4, 1, 1, 4, 4 , 1),
            Observable<Int>.interval(1, scheduler: MainScheduler.instance)
        ) { f, _ in f }
        
        let comparedValuesInSequence = input.provider.compareLastElements(
            source: timer.debug("[:compareLastElements.source]")
        ).debug("[:compareLastElements.Result]")
        
        let maxIndex = input.provider.maxIndex(
            source: filteredSequence.debug("[:maxIndex.source]")
        ).debug("[:maxIndex.Result]")
        
        let maybe = Maybe<String>.create { event in
            if Bool.random() {
                event(.success("success"))
            } else {
                event(.error(SequenceError.default))
            }
            
            return Disposables.create()
        }.delay(4, scheduler: MainScheduler.instance).asObservable()
        
        let sourceSequence = Bool.random()
            ? Observable<Int>.empty()
            : Observable<Int>.interval(2, scheduler: MainScheduler.instance).take(5)
        
        let reducedSequence = input.provider.ifNotEmptyReduceToVoid(
            source: sourceSequence.debug("[:ifNotEmptyReduceToVoid.source]"),
            request: maybe.debug("[:ifNotEmptyReduceToVoid.request]")
        ).debug("[:ifNotEmptyReduceToVoid.Result]")
        
        let mockArray = (0...7).map {
            MockEntity(id: "\($0)", enabled: false)
        }
        
        let idsSequence = Observable<Int>.of(3, 1, 6, 0, 4, 5, 2, 7).flatMap { index in
            Observable<String>.just("\(index)")
                .delay(RxTimeInterval(abs(4 - index)), scheduler: MainScheduler.instance)
        }
        
        let updatedSequence = input.provider.update(
            source: Observable.just(mockArray).debug("[:update.source]"),
            by: idsSequence.debug("[:update.by]")
        ).debug("[:update.Result]")
        
        let retryMaybe = Maybe<String>.create { event in
            switch Int.random(in: 0...6) {
            case 0...1:
                event(.success("success"))
            case 2...6:
                event(.error(SequenceError.default))
            default:
                event(.completed)
            }
            
            return Disposables.create()
        }.delay(5, scheduler: MainScheduler.instance).asObservable()
        
        let showRetryAlert = input.uiProvider.showRetryAlert(
            source: retryMaybe.debug("[:showRetryAlert.source]"),
            input.retryAlertOwner
        ).debug("[:showRetryAlert.source]")
        
        return Output(
            switchedSequence: switchedSequence,
            filteredBySignal: filteredBySignal,
            comparedValuesInSequence: comparedValuesInSequence,
            maxIndex: maxIndex,
            reducedSequence: reducedSequence,
            updatedSequence: updatedSequence.map { $0 as [EducationEntity] },
            showRetryAlert: showRetryAlert
        )
    }
}

private struct MockEntity: EducationEntity {
    let id: String
    var enabled: Bool
}

private enum SequenceError: Error {
    case `default`
}
