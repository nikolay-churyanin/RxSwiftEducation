//
//  ViewController.swift
//  RxSwiftEducation
//
//  Created by Nikolay Churyanin on 07/04/2019.
//  Copyright © 2019 Nikolay Churyanin. All rights reserved.
//

import UIKit
import RxSwift

class ViewController: UIViewController {

    private let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        let eProvider: RxEducationProvider
//        let eUiProvider: RxEducationUIProvider
        
//        let input = RxEducationManager.Input.init(
//            provider: eProvider,
//            uiProvider: rUI,
//            retryAlertOwner: self
//        )
        
//        let manager = RxEducationManager().configure(input: input)

//        manager.
    }
}
